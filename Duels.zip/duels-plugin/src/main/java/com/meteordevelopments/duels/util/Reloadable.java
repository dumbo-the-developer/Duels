package com.meteordevelopments.duels.util;

public interface Reloadable {
}
